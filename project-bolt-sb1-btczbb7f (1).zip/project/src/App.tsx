import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Portfolio from './components/Portfolio';
import Features from './components/Features';
import Stats from './components/Stats';
import Services from './components/Services';
import Workflow from './components/Workflow';
import Testimonial from './components/Testimonial';
import Comparison from './components/Comparison';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <Header />
      <Hero />
      <Portfolio />
      <Features />
      <Stats />
      <Services />
      <Workflow />
      <Testimonial />
      <Comparison />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;