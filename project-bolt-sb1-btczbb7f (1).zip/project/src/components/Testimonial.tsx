import React from 'react';
import { motion } from 'framer-motion';
import { Quote, Star } from 'lucide-react';

const Testimonial = () => {
  return (
    <section className="py-24 bg-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/10 via-transparent to-green-900/10" />
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.3, 0.5, 0.3]
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-20 right-20 w-64 h-64 bg-gradient-to-br from-cyan-400/10 to-green-400/10 rounded-full blur-3xl"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, type: "spring", bounce: 0.3 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <motion.div
            whileHover={{ rotate: 5, scale: 1.1 }}
            className="w-20 h-20 bg-gradient-to-br from-cyan-400 to-green-400 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-lg"
          >
            <Quote size={32} className="text-white" />
          </motion.div>

          <motion.blockquote
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            viewport={{ once: true }}
            className="text-2xl md:text-3xl font-light text-gray-200 mb-8 leading-relaxed"
          >
            "P2P TechEdge transformed our digital presence completely. Their strategic approach and attention to detail resulted in a{' '}
            <span className="bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent font-semibold">
              300% increase in conversions
            </span>{' '}
            within the first quarter."
          </motion.blockquote>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            viewport={{ once: true }}
            className="flex items-center justify-center gap-6"
          >
            <div className="w-16 h-16 bg-gradient-to-br from-gray-700 to-gray-800 rounded-full flex items-center justify-center border-2 border-cyan-400/30">
              <span className="text-xl font-bold text-cyan-400">SJ</span>
            </div>
            
            <div className="text-left">
              <h4 className="text-xl font-semibold text-white mb-1">Sarah Johnson</h4>
              <p className="text-gray-400">CEO, TechFlow Solutions</p>
              
              <div className="flex items-center gap-1 mt-2">
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: 0.7 + i * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Star size={16} className="text-yellow-400 fill-current" />
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Floating Elements */}
          <motion.div
            animate={{ y: [0, -10, 0], rotate: [0, 5, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-10 left-10 w-8 h-8 bg-cyan-400/20 rounded-lg blur-sm"
          />
          <motion.div
            animate={{ y: [0, 10, 0], rotate: [0, -5, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            className="absolute bottom-10 right-10 w-12 h-12 bg-green-400/20 rounded-full blur-sm"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonial;