import React from 'react';
import { motion } from 'framer-motion';
import { Target, TrendingUp, Users } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: Target,
      title: 'Design with Purpose',
      description: 'Every element serves a strategic purpose, from user flow to conversion optimization.',
      color: 'from-cyan-400 to-blue-500'
    },
    {
      icon: TrendingUp,
      title: 'Built for Conversion',
      description: 'Data-driven design decisions that turn visitors into customers and drive revenue growth.',
      color: 'from-green-400 to-cyan-500'
    },
    {
      icon: Users,
      title: 'Brand-Aligned User Flow',
      description: 'Seamless user experiences that reflect your brand identity and values at every touchpoint.',
      color: 'from-purple-400 to-pink-500'
    }
  ];

  return (
    <section className="py-24 bg-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/10 via-transparent to-green-900/10" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Rethinking
            <span className="bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
              {' '}Website Design
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            We don't just create beautiful websites. We craft strategic digital experiences that drive business growth.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6, 
                  delay: index * 0.2,
                  type: "spring",
                  bounce: 0.3
                }}
                viewport={{ once: true }}
                whileHover={{ y: -10 }}
                className="group relative bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800 hover:border-cyan-400/50 transition-all duration-300"
              >
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity duration-300`} />
                
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:shadow-lg transition-all duration-300`}
                >
                  <IconComponent size={28} className="text-white" />
                </motion.div>

                <h3 className="text-2xl font-bold mb-4 group-hover:text-cyan-400 transition-colors duration-200">
                  {feature.title}
                </h3>
                
                <p className="text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors duration-200">
                  {feature.description}
                </p>

                {/* Animated Border */}
                <motion.div
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  transition={{ duration: 0.8, delay: index * 0.2 + 0.5 }}
                  viewport={{ once: true }}
                  className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-cyan-400 to-green-400 origin-left"
                />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;