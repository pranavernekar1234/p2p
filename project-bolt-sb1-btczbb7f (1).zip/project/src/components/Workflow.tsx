import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Search, Vibrate as Strategy, Code, BarChart, FileText, RefreshCw } from 'lucide-react';
import { useRef } from 'react';

const Workflow = () => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const progressHeight = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  const steps = [
    {
      icon: Search,
      title: 'Discovery',
      description: 'Deep dive into your business goals, target audience, and competitive landscape.',
      color: 'from-cyan-400 to-blue-500'
    },
    {
      icon: Strategy,
      title: 'Strategy Development',
      description: 'Create a comprehensive strategy aligned with your business objectives.',
      color: 'from-blue-500 to-purple-500'
    },
    {
      icon: Code,
      title: 'Implementation',
      description: 'Bring the strategy to life with cutting-edge design and development.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: BarChart,
      title: 'Monitoring',
      description: 'Track performance metrics and user behavior to ensure optimal results.',
      color: 'from-pink-500 to-red-500'
    },
    {
      icon: FileText,
      title: 'Reporting',
      description: 'Provide detailed insights and recommendations for continuous improvement.',
      color: 'from-red-500 to-orange-500'
    },
    {
      icon: RefreshCw,
      title: 'Review & Adapt',
      description: 'Iterate and optimize based on data-driven insights and feedback.',
      color: 'from-orange-500 to-green-500'
    }
  ];

  return (
    <section ref={containerRef} className="py-24 bg-gradient-to-b from-black to-gray-900 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Our Approach to
            <span className="bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
              {' '}Your Success
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A proven methodology that ensures every project delivers exceptional results and drives business growth.
          </p>
        </motion.div>

        <div className="relative">
          {/* Progress Line */}
          <div className="absolute left-8 md:left-1/2 md:transform md:-translate-x-0.5 top-0 w-0.5 h-full bg-gray-800">
            <motion.div
              style={{ height: progressHeight }}
              className="w-full bg-gradient-to-b from-cyan-400 to-green-400 origin-top"
            />
          </div>

          <div className="space-y-16">
            {steps.map((step, index) => {
              const IconComponent = step.icon;
              const isEven = index % 2 === 0;

              return (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, x: isEven ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className={`flex items-center ${isEven ? 'md:flex-row' : 'md:flex-row-reverse'} flex-col md:gap-16 gap-8`}
                >
                  {/* Content */}
                  <div className={`flex-1 ${isEven ? 'md:text-right' : 'md:text-left'} text-center md:text-left`}>
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800 hover:border-cyan-400/50 transition-all duration-300 group"
                    >
                      <div className={`flex items-center gap-4 mb-4 ${isEven ? 'md:justify-end' : 'md:justify-start'} justify-center`}>
                        <div className={`w-12 h-12 bg-gradient-to-br ${step.color} rounded-xl flex items-center justify-center group-hover:shadow-lg transition-all duration-300`}>
                          <IconComponent size={20} className="text-white" />
                        </div>
                        <h3 className="text-2xl font-bold group-hover:text-cyan-400 transition-colors duration-200">
                          {step.title}
                        </h3>
                      </div>
                      <p className="text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors duration-200">
                        {step.description}
                      </p>
                    </motion.div>
                  </div>

                  {/* Timeline Node */}
                  <motion.div
                    whileHover={{ scale: 1.2 }}
                    className="relative z-10 w-16 h-16 bg-gradient-to-br from-cyan-400 to-green-400 rounded-full flex items-center justify-center shadow-lg"
                  >
                    <span className="text-black font-bold text-lg">{index + 1}</span>
                    <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 to-green-400 rounded-full animate-ping opacity-20" />
                  </motion.div>

                  {/* Spacer for mobile */}
                  <div className="flex-1 md:block hidden" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Workflow;