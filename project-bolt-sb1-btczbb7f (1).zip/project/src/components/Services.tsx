import React from 'react';
import { motion } from 'framer-motion';
import { Palette, Zap, Smartphone, RefreshCw, ArrowRight } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Palette,
      title: 'Custom Website Design',
      description: 'Bespoke designs tailored to your brand identity and business objectives.',
      features: ['Brand Strategy', 'UI/UX Design', 'Responsive Layout', 'Performance Optimization']
    },
    {
      icon: Zap,
      title: 'Landing Page Design',
      description: 'High-converting landing pages that turn visitors into customers.',
      features: ['A/B Testing', 'Conversion Optimization', 'Lead Generation', 'Analytics Setup']
    },
    {
      icon: Smartphone,
      title: 'UI/UX Design Services',
      description: 'User-centered design that creates intuitive and engaging experiences.',
      features: ['User Research', 'Wireframing', 'Prototyping', 'Usability Testing']
    },
    {
      icon: RefreshCw,
      title: 'Website Redesign',
      description: 'Transform your existing website into a modern, high-performing asset.',
      features: ['Site Audit', 'Modern Design', 'SEO Optimization', 'Migration Support']
    }
  ];

  return (
    <section id="services" className="py-24 bg-black relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="%23ffffff" fill-opacity="0.1"%3E%3Cpath d="M20 20c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm10 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z"/%3E%3C/g%3E%3C/svg%3E')]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Our
            <span className="bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
              {' '}Services
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Comprehensive design solutions that drive growth and deliver exceptional user experiences.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
                className="group bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800 hover:border-cyan-400/50 transition-all duration-300 relative overflow-hidden"
              >
                {/* Hover Glow Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 to-green-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <div className="relative z-10">
                  <motion.div
                    whileHover={{ scale: 1.1, x: 10 }}
                    transition={{ type: "spring", stiffness: 300 }}
                    className="flex items-center mb-6"
                  >
                    <div className="w-14 h-14 bg-gradient-to-br from-cyan-400 to-green-400 rounded-xl flex items-center justify-center mr-4 group-hover:shadow-lg transition-all duration-300">
                      <IconComponent size={24} className="text-white" />
                    </div>
                    <h3 className="text-2xl font-bold group-hover:text-cyan-400 transition-colors duration-200">
                      {service.title}
                    </h3>
                  </motion.div>

                  <p className="text-gray-400 mb-6 leading-relaxed group-hover:text-gray-300 transition-colors duration-200">
                    {service.description}
                  </p>

                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <motion.li
                        key={feature}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.2 + featureIndex * 0.1 }}
                        viewport={{ once: true }}
                        className="flex items-center text-gray-300"
                      >
                        <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3" />
                        {feature}
                      </motion.li>
                    ))}
                  </ul>

                  <motion.button
                    whileHover={{ x: 5 }}
                    className="text-cyan-400 font-semibold flex items-center gap-2 group-hover:text-cyan-300 transition-colors duration-200"
                  >
                    Learn More
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
                  </motion.button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;