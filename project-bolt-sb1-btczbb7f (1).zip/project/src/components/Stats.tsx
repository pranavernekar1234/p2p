import React, { useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const Stats = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const stats = [
    { label: 'Conversion Rate', value: 92, suffix: '%', prefix: '↑', color: 'text-green-400' },
    { label: 'Bounce Rate', value: 53, suffix: '%', prefix: '↓', color: 'text-cyan-400' },
    { label: 'SEO Score', value: 76, suffix: '%', prefix: '↑', color: 'text-purple-400' }
  ];

  const Counter = ({ value, suffix, prefix, color }: { value: number; suffix: string; prefix: string; color: string }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
      if (isInView) {
        const timer = setInterval(() => {
          setCount(prev => {
            if (prev < value) {
              return prev + 1;
            }
            clearInterval(timer);
            return value;
          });
        }, 30);
        return () => clearInterval(timer);
      }
    }, [isInView, value]);

    return (
      <span className={`text-5xl md:text-6xl font-bold ${color}`}>
        {prefix}{count}{suffix}
      </span>
    );
  };

  return (
    <section ref={ref} className="py-24 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden">
      {/* Animated Background */}
      <motion.div
        animate={{
          background: [
            'radial-gradient(circle at 20% 50%, rgba(6, 182, 212, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 80% 50%, rgba(16, 185, 129, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 20% 50%, rgba(6, 182, 212, 0.1) 0%, transparent 50%)'
          ]
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute inset-0"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Results That
            <span className="bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
              {' '}Speak Volumes
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Our data-driven approach delivers measurable improvements across all key performance indicators.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.2,
                type: "spring",
                bounce: 0.4
              }}
              viewport={{ once: true }}
              className="text-center bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800 hover:border-cyan-400/50 transition-all duration-300 group"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="mb-4"
              >
                <Counter 
                  value={stat.value} 
                  suffix={stat.suffix} 
                  prefix={stat.prefix}
                  color={stat.color}
                />
              </motion.div>
              
              <h3 className="text-xl font-semibold text-gray-300 group-hover:text-white transition-colors duration-200">
                {stat.label}
              </h3>
              
              {/* Progress Bar */}
              <motion.div
                initial={{ width: 0 }}
                whileInView={{ width: `${stat.value}%` }}
                transition={{ duration: 1.5, delay: index * 0.2 + 0.5 }}
                viewport={{ once: true }}
                className={`h-1 bg-gradient-to-r ${
                  stat.color.includes('green') ? 'from-green-400 to-green-600' :
                  stat.color.includes('cyan') ? 'from-cyan-400 to-cyan-600' :
                  'from-purple-400 to-purple-600'
                } rounded-full mt-4 mx-auto max-w-xs`}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;